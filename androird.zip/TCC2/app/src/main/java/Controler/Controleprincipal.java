package Controler;

import java.sql.SQLException;

import Model.Model;
import View.telaLogin;

public class Controleprincipal {
    View.telaLogin telaLogin;

    public void iniciar() throws SQLException {

        //model = new Model();
        //model.Iniciar();

        telaLogin = new telaLogin();
        telaLogin.setControle(this);
        //telaLogin.inicio();
    }
}