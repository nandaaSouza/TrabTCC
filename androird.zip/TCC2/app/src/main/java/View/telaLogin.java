package View;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tcc.R;

import Controler.Controleprincipal;

public class telaLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_login);
    }

    private Controleprincipal c;

    public void setControle(Controleprincipal c) {
        this.c = c;
    }
}
