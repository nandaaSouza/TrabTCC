package com.example.gados;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class Fragmento1 extends Fragment {
    private Button add;
    private Fazenda f;
    private static final String TAG="tela Animal";
    private String codigoAnimal="";
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private ArrayAdapter<String> adaptador;
    private List<String> Animais;
    private ListView ListaAnimal;
    private FirebaseAuth mAuth;
    private ArrayList <Animal> animais;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        f = (Fazenda) getArguments().getSerializable("Fazenda");
        View tela=inflater.inflate(R.layout.tela_principal, container, false);
        add=tela.findViewById(R.id.adicionar);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent adi=new Intent(getContext(),Tela_adicionar_animal.class);
                adi.putExtra("Fazenda",f);
                startActivity(adi);
            }
        });
        ListaAnimal=tela.findViewById(R.id.listaanimais);
        Pesquisa();
        animais=new ArrayList<>();
        return tela;
    }
    //TODO: fazer pesquisa
    private void Pesquisa() {
        db.collection("animal").whereEqualTo("dono",f.getId())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            Animais=new ArrayList<>();
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData());
                                codigoAnimal = document.get("codigo").toString();
                                Animais.add("Código Animal: " + codigoAnimal);
                                //adicionando o objeto Animal dentro do array animal

                                Animal ani = document.toObject(Animal.class);
                                animais.add(ani);
                                ani.setId(document.getId());
                            }
                            adaptador=new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,Animais);

                            ListaAnimal.setAdapter(adaptador);
                            ListaAnimal.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    Intent itent = new Intent(getContext(), TelaVerMais.class);
                                    Animal an=animais.get(position);
                                    itent.putExtra("PosicaoAnimal",an);
                                    startActivity(itent);
                                }
                            });
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });
    }
}