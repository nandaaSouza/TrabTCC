package com.example.gados;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class tela_add_fazendas extends AppCompatActivity {
    private static final String TAG = "tela add fazendas";
    private FirebaseFirestore banco;
    private FirebaseAuth mAuth;
    private Button cancelar;
    private Button addfazenda;
    private EditText nomefazenda;
    private EditText nomeusuario;
    private EditText cidade;
    private EditText estado;
    private EditText areas;
    private EditText lotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_add_fazendas);
        nomeusuario = findViewById(R.id.ETnome);
        cancelar = findViewById(R.id.BcancelarAddFazenda);
        addfazenda = findViewById(R.id.BfinalizarAddFazenda);
        nomefazenda = findViewById(R.id.ETnomef);
        cidade = findViewById(R.id.ETcidade);
        estado = findViewById(R.id.ETestado);
        areas = findViewById(R.id.ETarea);
        lotes = findViewById(R.id.ETlotes);
        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(tela_add_fazendas.this, tela_fazendas.class);
                startActivity(it);
            }
        });
        mAuth = FirebaseAuth.getInstance();


        addfazenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Intent it = new Intent(tela_add_fazendas.this, tela_fazendas.class);
                String Nomefazenda = nomefazenda.getText().toString();
                String Cidade = cidade.getText().toString();
                String Estado = estado.getText().toString();
                String Area = areas.getText().toString();
                String Lotes = lotes.getText().toString();
                if (Nomefazenda.isEmpty() || Cidade.isEmpty() || Estado.isEmpty() || Area.isEmpty() || Lotes.isEmpty()) {
                    Toast.makeText(tela_add_fazendas.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {
                    banco = FirebaseFirestore.getInstance();

                    Fazenda f = new Fazenda(Area, Cidade, Lotes, Nomefazenda, Estado, mAuth.getUid());

                    banco.collection("fazenda").document()
                            .set(f)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(tela_add_fazendas.this, "Os dados foram inseridos", Toast.LENGTH_SHORT).show();
                                    startActivity(it);
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(TAG, e.getMessage());
                                }
                            });
                }

            }
        });
    }
}
