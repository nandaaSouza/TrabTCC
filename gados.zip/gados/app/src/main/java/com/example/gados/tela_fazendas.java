package com.example.gados;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class tela_fazendas extends AppCompatActivity {
    private static final String TAG="tela fazendas";
    private String NomeFazenda="";
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private ArrayAdapter<String> adaptador;
    private List<String> fazendas;
    private ListView Listafazendas;
    private FirebaseAuth mAuth;
    private ArrayList <Fazenda> Fazendas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_fazendas);
        Fazendas=new ArrayList<>();
        Button adicionarfazenda=findViewById(R.id.BAddFazenda);
        Button sair=findViewById(R.id.Bsair);
        adicionarfazenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(tela_fazendas.this,tela_add_fazendas.class);
                startActivity(it);
            }
        });
        sair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(tela_fazendas.this, telalogin.class);
                startActivity(it);
            }
        });

        Listafazendas=findViewById(R.id.listaFazendas);
        mAuth = FirebaseAuth.getInstance();
        Pesquisa();

    }
    private void Pesquisa() {
        db.collection("fazenda").whereEqualTo("dono",mAuth.getUid())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            fazendas=new ArrayList<>();
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData());
                                NomeFazenda = document.get("nome").toString();
                                fazendas.add("Fazenda " + NomeFazenda);
                                //adicionando o objeto fazenda dentro do array fazenda
                                Fazenda fa = document.toObject(Fazenda.class);
                                Fazendas.add(fa);
                                fa.setId(document.getId());
                            }
                            adaptador=new ArrayAdapter<String>(tela_fazendas.this,android.R.layout.simple_list_item_1,fazendas);

                    Listafazendas.setAdapter(adaptador);
                    Listafazendas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Intent it = new Intent(tela_fazendas.this, Telaprincipalf.class);
                            it.putExtra("Fazenda",Fazendas.get(position));
                            startActivity(it);
                        }
                    });
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });
//
    }
}
