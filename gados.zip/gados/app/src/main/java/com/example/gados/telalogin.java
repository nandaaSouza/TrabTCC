package com.example.gados;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class telalogin extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth mAuth;
    private static final String TAG = "tela Login";
    private EditText edtemail;
    private EditText edtsenha;
    private CheckBox conectado;
    private Button sairtelafazendas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FirebaseApp.initializeApp(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_login);
        mAuth = FirebaseAuth.getInstance();
        Button botao = findViewById(R.id.bEntrar);
        Button botaonovo = findViewById(R.id.bNovoUsuario);
        botaonovo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent novousuario = new Intent(telalogin.this, telaNovoUsuario.class);
                startActivity(novousuario);
            }
        });
        edtemail = findViewById(R.id.PlainUsuario);
        edtsenha = findViewById(R.id.PassSenha);
        conectado = findViewById(R.id.CBconectado);
        sairtelafazendas=findViewById(R.id.Bsair);
        botao.setOnClickListener(this);
        Pair<String, String> credenciais = RecuperaCredenciais();
        if (credenciais != null) {
            login(credenciais.second, credenciais.first);
        }

    }

    @Override
    public void onClick(View v) {
        String email = edtemail.getText().toString();
        String senha = edtsenha.getText().toString();
        if (email.isEmpty() || senha.isEmpty()) {
            Toast.makeText(telalogin.this, "Preencha todos os campos",
                    Toast.LENGTH_SHORT).show();
        } else {
            login(email, senha);
        }
    }

    public void login(final String email, final String senha) {
        final Intent it = new Intent(telalogin.this, tela_fazendas.class);
        mAuth.signInWithEmailAndPassword(email, senha)
                .addOnCompleteListener(telalogin.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "sucesso no login");
//                            FirebaseUser user = mAuth.getCurrentUser();
                            if(conectado.isSelected()) {
                                SalvaCredencial(senha, email);
                            }
                            startActivity(it);
                            finish();
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "Falha no login", task.getException());
                            Toast.makeText(telalogin.this, "Falha de Autenticação; Tente novamente.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    public void SalvaCredencial(String senha, String email) {
        SharedPreferences.Editor editor = getSharedPreferences("credenciais", Activity.MODE_PRIVATE).edit();
        editor.putString("Senha", senha);
        editor.putString("Email", email);
        editor.commit();
    }

    public Pair<String, String> RecuperaCredenciais() {
        SharedPreferences preferences = getSharedPreferences("credenciais", Activity.MODE_PRIVATE);

        String senha = preferences.getString("Senha", null);
        String email = preferences.getString("Email", null);

        if (senha != null && email != null) {
            return new Pair<String, String>(senha, email);
        }
        return null;
    }
}
