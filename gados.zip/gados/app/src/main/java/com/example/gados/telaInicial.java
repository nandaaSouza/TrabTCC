package com.example.gados;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class telaInicial extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_inicial);
        finish();
    }
}
