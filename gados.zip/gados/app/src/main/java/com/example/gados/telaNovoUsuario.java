package com.example.gados;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class telaNovoUsuario extends AppCompatActivity implements View.OnClickListener {
    private FirebaseAuth mAuth;
    private FirebaseFirestore banco;
    private static final String TAG="tela novo Usuario";
    private AlertDialog alerta;
    private Button cadastrar;
    private EditText user;
    private EditText senha;
    private EditText email;
    private EditText nome;
    private EditText telefone;
    private EditText confirmasenha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_novo_usuario);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Bem vindo ao GADO's");
        builder.setMessage(getString(R.string.mensagem_cadastro));
        builder.setPositiveButton("Vamos lá!!!", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface arg0, int arg1) {
            finish();
            Intent it=new Intent(telaNovoUsuario.this,tela_fazendas.class);
            startActivity(it);
            }
        });
        alerta = builder.create();

        nome=findViewById(R.id.ETnome);
        telefone=findViewById(R.id.ETtelefone);
        cadastrar= findViewById(R.id.bcadastrarUsuario);
        email=findViewById(R.id.ETemail);
        senha=findViewById(R.id.ETSenha);
        confirmasenha=findViewById(R.id.ETconfirmaSenha);

        cadastrar.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        String semail=email.getText().toString();
        String ssenha=senha.getText().toString();
        String nnome=nome.getText().toString();
        String ntelefone=telefone.getText().toString();
        String confsenha=confirmasenha.getText().toString();
        if (semail.isEmpty() || ssenha.isEmpty()){
            Toast.makeText(telaNovoUsuario.this, "Preencha todos os campos",
                    Toast.LENGTH_SHORT).show();
        }else {
            if ( confirmando(ssenha,confsenha)==true) {
                cadastrar(semail, ssenha);
                iniciarbanco(nnome,ntelefone,ssenha,semail);
            }else{
                Toast.makeText(telaNovoUsuario.this, "senhas incompativeis, Verifique novamente",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void cadastrar(String semail,String ssenha){
        mAuth = FirebaseAuth.getInstance();
        mAuth.createUserWithEmailAndPassword(semail,ssenha)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "Cadastrado com sucesso");
                            FirebaseUser user = mAuth.getCurrentUser();
                            alerta.show();
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "Não cadastrou", task.getException());
                                Toast.makeText(telaNovoUsuario.this, "Não cadastrado, tente novamente, verifique todos os dados."+task.getException(),
                                        Toast.LENGTH_SHORT).show();
                            }
                        // ...
                    }

                });
    }
    public void iniciarbanco(String nome,String telefone,String senha,String Email){

        banco= FirebaseFirestore.getInstance();
        // Create a new user with a first and last name
        Map<String, Object> usuario = new HashMap<>();
        usuario.put("nome", nome);
        usuario.put("telefone",telefone);
        usuario.put("senha",senha);
        usuario.put("email",Email);

        // Add a new document with a generated ID
        banco.collection("usuario").document("usuario "+nome)
                .set(usuario)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
            public void onSuccess(Void aVoid) {
                Log.w(TAG, "Usuario cadastrado com sucesso");
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Erro ao cadastrar usuario"+e);
                    }
                });
    }
    public boolean confirmando(String senha,String confirmasenha){
        if(senha.equals(confirmasenha)){
            return true;
        }else{
            return false;
        }
    }
}