package com.example.gados;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class tela_proximo_adicionar_animal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_proximo_adicionar_animal);
        Button finalizar=findViewById(R.id.bfinalizar);
        finalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fin=new Intent(tela_proximo_adicionar_animal.this, Telaprincipalf.class);
                startActivity(fin);
                finish();
            }
        });
    }
}
