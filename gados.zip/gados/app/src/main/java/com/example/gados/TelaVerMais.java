package com.example.gados;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TelaVerMais extends AppCompatActivity {
    private TextView codigo;
    private TextView cor;
    private TextView raca;
    private TextView dataentrada;
    private TextView nascimento;
    private String data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_ver_mais);
        Intent itent=getIntent();
        final Animal animal=(Animal) itent.getSerializableExtra("PosicaoAnimal");
        Button tabela=findViewById(R.id.btabelaNutricional);
        tabela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent atabela=new Intent(TelaVerMais.this,Tela_tabela_nutricional.class);
                startActivity(atabela);
            }
        });
        Button grafico=findViewById(R.id.bGraficos);
        grafico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent agrafico=new Intent(TelaVerMais.this,tela_grafico.class);
                startActivity(agrafico);
            }
        });
        Button editar=findViewById(R.id.bEditarVM);
        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editando=new Intent(TelaVerMais.this,telaeditando.class);
                editando.putExtra("Animal",animal);
                startActivity(editando);
            }
        });
        codigo=findViewById(R.id.TVCodigo);
        cor=findViewById(R.id.TVcor);
        raca=findViewById(R.id.TVraca);
        dataentrada=findViewById(R.id.TVdatae);
        nascimento=findViewById(R.id.TVnascimento);


        codigo.setText(animal.getCodigo());
        cor.setText(animal.getCorpelagem());
        raca.setText(animal.getRaca());
        dataentrada.setText(animal.getDataentrada());
        nascimento.setText(animal.getNascimento());



  }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==200){

        }
    }
}
