package com.example.gados;

import com.google.android.gms.common.data.TextFilterable;

import java.io.Serializable;

public class Fazenda implements Serializable {

    String area;
    String cidade;
    String lotes;
    String nome;
    String estado;
    //Id do usuario no Firebase
    String dono;
    String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Fazenda() {
    }

    public String getArea() {
        return area;
    }

    public Fazenda(String area, String cidade, String lotes, String nome, String estado, String dono) {
        this.area = area;
        this.cidade = cidade;
        this.lotes = lotes;
        this.nome = nome;
        this.estado = estado;
        this.dono = dono;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getLotes() {
        return lotes;
    }

    public void setLotes(String lotes) {
        this.lotes = lotes;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
