package com.example.gados;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class InicialActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_inicial);
        View telaBonitinha=findViewById(R.id.telaInicial);
        telaBonitinha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(InicialActivity.this, telalogin.class);
                startActivity(it);
                finish();
            }
        });
    }
}
