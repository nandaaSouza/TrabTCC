package com.example.gados;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

public class telaeditando extends AppCompatActivity {
    private static final String TAG = "tela editando";
    private FirebaseFirestore banco;
    private EditText codigo;
    private EditText raca;
    private EditText dataentrada;
    private EditText nascimento;
    private EditText corpelo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.telaeditando);

        Intent itent=getIntent();
        final Animal animal=(Animal) itent.getSerializableExtra("Animal");

        codigo=findViewById(R.id.ETcodi);
        raca=findViewById(R.id.ETrac);
        dataentrada=findViewById(R.id.ETdataentrada);
        nascimento=findViewById(R.id.ETnascimento);
        corpelo=findViewById(R.id.ETcorpelo);

        codigo.setText(animal.getCodigo());
        raca.setText(animal.getRaca());
        dataentrada.setText(animal.getDataentrada());
        nascimento.setText(animal.getNascimento());
        corpelo.setText(animal.getCorpelagem());



        Button salvar=findViewById(R.id.bsalvar);
        salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Codigo = codigo.getText().toString();
                String Raca = raca.getText().toString();
                String Dataentrada = dataentrada.getText().toString();
                String Nascimento= nascimento.getText().toString();
                String Corpelagem= corpelo.getText().toString();

                if (Codigo.isEmpty() || Raca.isEmpty() || Dataentrada.isEmpty() || Nascimento.isEmpty() || Corpelagem.isEmpty()) {
                    Toast.makeText(telaeditando.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {
                    banco = FirebaseFirestore.getInstance();

                    Animal a = new Animal(Codigo,Raca,Dataentrada,Nascimento,Corpelagem,animal.getDono());

                    banco.collection("animal").document()
                            .set(animal.getId())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(telaeditando.this, "Os dados foram inseridos", Toast.LENGTH_SHORT).show();
                                    setResult(200);
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(TAG, e.getMessage());
                                }
                            });
                }
            }
        });

    }
}
