package com.example.gados;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class Tela_adicionar_animal extends AppCompatActivity {
    private static final String TAG = "tela add animais";
    private FirebaseFirestore banco;
    private FirebaseAuth mAuth;
    private EditText codigo;
    private EditText raca;
    private EditText dataentrada;
    private Spinner aptidao;
    private EditText nascimento;
    private Spinner categoria;
    private EditText corpelagem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_adicionar_animal);
        codigo=findViewById(R.id.ETcodigo);
        raca=findViewById(R.id.ETraca);
        dataentrada=findViewById(R.id.TdataEntAdd);
        nascimento=findViewById(R.id.TnascAdd);
        corpelagem=findViewById(R.id.Tcorpelagem);
        Button proximo= findViewById(R.id.bproximo);
        mAuth = FirebaseAuth.getInstance();
        Intent it=getIntent();
        final Fazenda f=(Fazenda) it.getSerializableExtra("Fazenda");
        Toast.makeText(this, f.getId(), Toast.LENGTH_SHORT).show();




        proximo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Intent prox=new Intent(Tela_adicionar_animal.this,Telaprincipalf.class);
                String Codigo = codigo.getText().toString();
                String Raca = raca.getText().toString();
                String Dataentrada = dataentrada.getText().toString();
                String Nascimento= nascimento.getText().toString();
                String Corpelagem= corpelagem.getText().toString();

                if (Codigo.isEmpty() || Raca.isEmpty() || Dataentrada.isEmpty() || Nascimento.isEmpty() || Corpelagem.isEmpty()) {
                    Toast.makeText(Tela_adicionar_animal.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {
                    banco = FirebaseFirestore.getInstance();

                    Animal a = new Animal(Codigo,Raca,Dataentrada,Nascimento,Corpelagem,f.getId());

                    banco.collection("animal").document()
                            .set(a)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(Tela_adicionar_animal.this, "Os dados foram inseridos", Toast.LENGTH_SHORT).show();
                                    startActivity(prox);
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(TAG, e.getMessage());
                                }
                            });
                }

            }
        });

    }
}
