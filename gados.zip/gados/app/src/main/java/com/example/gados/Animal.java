package com.example.gados;

import java.io.Serializable;

public class Animal implements Serializable {
    String codigo;
    String raca;
    String dataentrada;
    String nascimento;
    String corpelagem;
    String dono;
    String id;

    public Animal() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Animal(String codigo, String raca, String dataentrada, String nascimento, String corpelagem, String dono) {
        this.codigo = codigo;
        this.raca = raca;
        this.dataentrada = dataentrada;
        this.nascimento = nascimento;
        this.corpelagem = corpelagem;
        this.dono = dono;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getDataentrada() {
        return dataentrada;
    }

    public void setDataentrada(String dataentrada) {
        this.dataentrada = dataentrada;
    }

    public String getNascimento() {
        return nascimento;
    }

    public void setNascimento(String nascimento) {
        this.nascimento = nascimento;
    }

    public String getCorpelagem() {
        return corpelagem;
    }

    public void setCorpelagem(String corpelagem) {
        this.corpelagem = corpelagem;
    }
}