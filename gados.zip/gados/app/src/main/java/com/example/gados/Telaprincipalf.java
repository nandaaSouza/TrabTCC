package com.example.gados;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.Button;


public class Telaprincipalf extends AppCompatActivity {
    private TabAdapter adapter;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private Button voltar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.telaprincipal);
            viewPager = (ViewPager) findViewById(R.id.viewPager);
            tabLayout = (TabLayout) findViewById(R.id.tabLayout);
            voltar=findViewById(R.id.Bvoltar);
            voltar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent it= new Intent(Telaprincipalf.this,tela_fazendas.class);
                    startActivity(it);
                }
            });
        Intent it=getIntent();
        Fazenda f=(Fazenda) it.getSerializableExtra("Fazenda");
            adapter = new TabAdapter(getSupportFragmentManager());
            Fragmento1 frag=new Fragmento1();
            Bundle bundle=new Bundle();
            bundle.putSerializable("Fazenda",f);
            frag.setArguments(bundle);

            adapter.addFragment(frag, "animais");
            adapter.addFragment(new fragmento2(), "usuarios");

            viewPager.setAdapter(adapter);
            tabLayout.setupWithViewPager(viewPager);

        }
    }